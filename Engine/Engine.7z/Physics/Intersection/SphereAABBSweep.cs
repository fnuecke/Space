﻿using Engine.Math;

namespace Engine.Physics.Intersection
{
    sealed class SphereAABBSweep
    {
        /// <summary>
        /// Test for collision between moving box and sphere.
        /// </summary>
        /// <param name="ra">radius of sphere</param>
        /// <param name="A0">previous position of sphere</param>
        /// <param name="A1">current position of sphere</param>
        /// <param name="rb">extents of AABB</param>
        /// <param name="B0">previous position of AABB</param>
        /// <param name="B1">current position of AABB</param>
        /// <returns>true if the objects (did) collide.</returns>
        /// <see cref="http://www.geometrictools.com/LibMathematics/Intersection/Wm5IntrBox2Circle2.cpp"/> 
        public static bool Test(FInt ra, ref FPoint A0, ref FPoint A1, ref FPoint eb, ref FPoint B0, ref FPoint B1)
        {
            // Convert circle center to box coordinates.
            FPoint diff = A1 - (B1 + eb / 2);
            FPoint vel = (B1 - B0) - (A1 - A0);

            if (diff.X < -eb.X)
            {
                if (diff.Y < -eb.Y)
                {
                    // region Rmm
                    return TestVertexRegion(ra, diff.X, diff.Y, vel.X, vel.Y, eb.X, eb.Y);
                }
                else if (diff.Y <= eb.Y)
                {
                    // region Rmz
                    return TestEdgeRegion(ra, diff.X, diff.Y, vel.X, vel.Y, eb.X, eb.Y);
                }
                else
                {
                    // region Rmp
                    return TestVertexRegion(ra, diff.X, -diff.Y, vel.X, -vel.Y, eb.X, eb.Y);
                }
            }
            else if (diff.X <= eb.X)
            {
                if (diff.Y < -eb.Y)
                {
                    // region Rzm
                    return TestEdgeRegion(ra, diff.Y, diff.X, vel.Y, vel.X, eb.Y, eb.X);
                }
                else if (diff.Y <= eb.Y)
                {
                    return true;
                }
                else
                {
                    // region Rzp
                    return TestEdgeRegion(ra, -diff.Y, diff.X, -vel.Y, vel.X, eb.Y, eb.X);
                }
            }
            else
            {
                if (diff.Y < -eb.Y)
                {
                    // region Rpm
                    return TestVertexRegion(ra, -diff.X, diff.Y, -vel.X, vel.Y, eb.X, eb.Y);
                }
                else if (diff.Y <= eb.Y)
                {
                    // region Rpz
                    return TestEdgeRegion(ra, -diff.X, diff.Y, -vel.X, vel.Y, eb.X, eb.Y);
                }
                else
                {
                    // region Rpp
                    return TestVertexRegion(ra, -diff.X, -diff.Y, -vel.X, -vel.Y, eb.X, eb.Y);
                }
            }
        }

        private static bool TestVertexRegion(FInt ra, FInt cx, FInt cy, FInt vx, FInt vy, FInt ex, FInt ey)
        {
            FInt dx = cx + ex;
            FInt dy = cy + ey;
            FInt rsqr = ra * ra;
            FInt diff = dx * dx + dy * dy - rsqr;
            if (diff <= (FInt)0)
            {
                // Circle is already intersecting the box.
                return true;
            }

            FInt dot = vx * dx + vy * dy;
            if (dot >= (FInt)0)
            {
                // Circle not moving towards box.
                return false;
            }

            FInt dotPerp = vx * dy - vy * dx;
            if (dotPerp >= (FInt)0)
            {
                // Potential contact on left edge.
                if (dotPerp <= ra * vy)
                {
                    // Lower left corner is first point of contact.
                    return true;
                }

                if (vx <= (FInt)0)
                {
                    // Passed corner, moving away from box.
                    return false;
                }

                FInt vsqr = vx * vx + vy * vy;
                dy = cy - ey;
                dotPerp = vx * dy - vy * dx;
                if (dotPerp >= (FInt)0 && dotPerp * dotPerp > rsqr * vsqr)
                {
                    // Circle misses box.
                    return false;
                }
            }
            else
            {
                // Potential contact on bottom edge.
                if (-dotPerp <= ra * vx)
                {
                    // Lower left corner is first point of contact.
                    return true;
                }

                if (vy <= (FInt)0)
                {
                    // Passed corner, moving away from box.
                    return false;
                }

                FInt vsqr = vx * vx + vy * vy;
                dx = cx - ex;
                dotPerp = vx * dy - vy * dx;
                if (-dotPerp >= (FInt)0 && dotPerp * dotPerp > rsqr * vsqr)
                {
                    // Circle misses box.
                    return false;
                }
            }

            return true;
        }

        private static bool TestEdgeRegion(FInt ra, FInt cx, FInt cy, FInt vx, FInt vy, FInt ex, FInt ey)
        {
            FInt dx = cx + ex;
            FInt xSignedDist = dx + ra;
            if (xSignedDist >= (FInt)0)
            {
                // Circle is already intersecting the box.
                return true;
            }

            if (vx <= (FInt)0)
            {
                // Circle not moving towards box.
                return false;
            }

            FInt rsqr = ra * ra;
            FInt vsqr = vx * vx + vy * vy;
            if (vy >= (FInt)0)
            {
                FInt dy = cy - ey;
                FInt dotPerp = vx * dy - vy * dx;
                if (dotPerp >= (FInt)0 && dotPerp * dotPerp > rsqr * vsqr)
                {
                    // Circle misses box.
                    return false;
                }
            }
            else
            {
                FInt dy = cy + ey;
                FInt dotPerp = vx * dy - vy * dx;
                if (dotPerp <= (FInt)0 && dotPerp * dotPerp > rsqr * vsqr)
                {
                    // Circle misses box.
                    return false;
                }
            }

            return true;
        }
    }
}
