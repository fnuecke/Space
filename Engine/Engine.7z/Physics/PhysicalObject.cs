﻿using Engine.Math;
using Engine.Simulation;

namespace Engine.Physics
{
    /// <summary>
    /// Base class for all physical objects.
    /// 
    /// This means the objects have a position, an orientation and a
    /// movement vector (speed / acceleration).
    /// </summary>
    public abstract class PhysicalObject
    {

        /// <summary>
        /// Current position of the object.
        /// </summary>
        protected FPoint position;

        /// <summary>
        /// Position before the last update.
        /// </summary>
        protected FPoint previousPosition;

        /// <summary>
        /// The angle of the current orientation.
        /// </summary>
        protected FInt orientation;

        /// <summary>
        /// Current directed acceleration of the object.
        /// </summary>
        protected FInt accelerationPosition;

        /// <summary>
        /// Current directed speed of the object.
        /// </summary>
        protected FInt speedPosition;

        /// <summary>
        /// Current rotation speed of the object.
        /// </summary>
        protected FInt speedRotation;

        public virtual IPhysicsEnabledState State { get; set; }

        public virtual void PreUpdate()
        {
        }

        public virtual void Update()
        {
            orientation += speedRotation;
            FPoint orientationVector = FPoint.Rotate(FPoint.Create((FInt)1, (FInt)0), orientation);

            previousPosition = position;
            speedPosition += accelerationPosition;
            position.X += orientationVector.X * speedPosition;
            position.Y += orientationVector.Y * speedPosition;
        }

        public virtual void PostUpdate()
        {
        }

    }
}
