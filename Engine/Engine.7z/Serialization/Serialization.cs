﻿using Microsoft.Xna.Framework.Content;
using Engine.Math;

namespace Engine.Serialization
{

    /// <summary>
    /// This is for reading data in binary format written with the FIntWriter.
    /// </summary>
    class FIntReader : ContentTypeReader<FInt>
    {
        protected override FInt Read(ContentReader input, FInt existingInstance)
        {
            return FInt.Create(input.ReadDouble());
        }
    }

}