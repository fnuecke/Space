﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Engine.Commands;

namespace Engine.Network
{
    public sealed class UDPProtocol<TGameInfo> : IProtocol<TGameInfo>
    {

#region IProtocol implementation

        /// <summary>
        /// Event dispatched whenever a game is found, either due to our own
        /// query or just because it was sent via broadcast.
        /// </summary>
        public event GameFoundDelegate<TGameInfo> OnGameFound;

        /// <summary>
        /// Event dispatched when a new client joins a group.
        /// </summary>
        public event ClientJoinedDelegate OnPlayerJoined;

        /// <summary>
        /// Event dispatched when a client leaves the group.
        /// </summary>
        public event ClientLeftDelegate OnPlayerLeft;

        /// <summary>
        /// The id of the local client for the game he is currently in.
        /// </summary>
        public int ClientId { get; private set; }

        /// <summary>
        /// Register a new command deserializer with this protocol, which is used to
        /// parse incoming packets. Note that the range from 0 to 20 is reserved for
        /// internal use.
        /// </summary>
        /// <param name="commandType">the type of the command the deserializer can handle.</param>
        /// <param name="deserializer">the actual deserializer implementation.</param>
        public void SetSerializer(uint commandType, CommandDeserializer deserializer, CommandSerializer serializer)
        {
            if (commandType < 20)
            {
                throw new ArgumentException("Command type is reserved.", "commandType");
            }
            if (socket != null)
            {
                throw new InvalidOperationException("Cannot add new serializers to an initialized protocol.");
            }
            serializers[commandType] = Tuple.Create(deserializer, serializer);
        }

        /// <summary>
        /// Set the serializers used for game info data.
        /// </summary>
        /// <param name="deserializer">the function used to deserialize the game info.</param>
        /// <param name="serializer">the function used to serialize the game info.</param>
        public void SetSerializer(GameInfoDeserializer<TGameInfo> deserializer, GameInfoSerializer serializer)
        {
            if (socket != null)
            {
                throw new InvalidOperationException("Cannot add new serializers to an initialized protocol.");
            }
            gameInfoDeserializer = deserializer;
            gameInfoSerializer = serializer;
        }

        /// <summary>
        /// Initialize network connectivity by opening a socket on the given port.
        /// This must be the same port on all clients. All serializers must be set
        /// before calling this, no network commands (FindHosts, Host, Join, Send,
        /// Receive) will function before calling this.
        /// </summary>
        /// <param name="port">the port the protocol runs on.</param>
        public void Init(ushort port)
        {
            if (socket != null)
            {
                throw new InvalidOperationException("Protocol can only be initialized once.");
            }

            this.port = port;
            broadcastEndpoint = new IPEndPoint(IPAddress.Broadcast, port);

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, 1);
            socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastLoopback, 0);
            socket.EnableBroadcast = true;

            socket.Bind(new IPEndPoint(IPAddress.Any, port));
            BeginReceiveMessage();
        }

        /// <summary>
        /// Send a query into the void to look if any games are running in the local network.
        /// </summary>
        public void FindHosts()
        {
            if (state == State.Unconnected)
            {
                Send(new GameQueryCommand(), null, 0);
            }
        }

        /// <summary>
        /// Start hosting a game.
        /// 
        /// This only determines how we respond to queries for open games
        /// from other clients (vie FindHosts) and join requests. If such
        /// commands arrive which in client mode (unconnected / joined)
        /// no events are raised.
        /// </summary>
        public void Host()
        {
            Leave();
            state = State.Host;
        }

        /// <summary>
        /// Join a game based on the address of the hosting machine.
        /// </summary>
        /// <param name="host">the address of the game host.</param>
        public void Join(IPEndPoint host)
        {

        }

        /// <summary>
        /// Leave the current game
        /// </summary>
        public void Leave()
        {
            state = State.Unconnected;
        }

        /// <summary>
        /// Check if there are any new messages, and if so retrieve them.
        /// This will clear the internal list of received messages.
        /// </summary>
        /// <returns>the list of new messages.</returns>
        public ICommand[] Receive()
        {
            ICommand[] commands = new Command[0];
            if (receivedCommands.Count > 0)
            {
                lock (receivedCommands)
                {
                    commands = receivedCommands.ToArray();
                    receivedCommands.Clear();
                }
            }
            return commands;
        }

        /// <summary>
        /// Send a packet to the given player. This method will only have
        /// an effect if in a game (hosted or joined).
        /// 
        /// To send a message to all players, use 0 as the player number.
        /// </summary>
        /// <param name="command">the command to send.</param>
        /// <param name="player">the player to send it to.</param>
        /// <param name="priority">the priority of the command.</param>
        public void Send(ICommand command, int player = 0, Priority priority = Priority.Informational)
        {
            if (player == 0)
            {
                // Send to all players.
                for (var i = 1; i < knownClients.Count; ++i)
                {
                    Send(command, i, priority);
                }
            }
            else
            {
                if (player == ClientId)
                {
                    // Message to ourselves, push it right back to the list of received messages.
                    command.Player = ClientId;
                    command.IsTentative = (state != State.Host);
                    receivedCommands.Push(command);
                }
                else
                {
                    // Message for another player, send it.
                    Send(command, knownClients[player], priorityMap[priority]);
                }
            }
        }

#endregion

        private enum State
        {
            /// <summary>
            /// Default state, before hosting or selecting a game.
            /// </summary>
            Unconnected,

            /// <summary>
            /// Currently acting as the host of a game.
            /// </summary>
            Host,

            /// <summary>
            /// Currently acting as the client of a game.
            /// </summary>
            Client
        }

        /// <summary>
        /// Quick lookup for enum -> actual delay.
        /// </summary>
        private static Dictionary<Priority, int> priorityMap = new Dictionary<Priority, int>()
        {
            { Priority.Informational, 0 },
            { Priority.Low, 100 },
            { Priority.Normal, 10 },
            { Priority.High, 1 }
        };

        /// <summary>
        /// The maximum number of retained commands to avoid duplicates.
        /// </summary>
        private const int MaxQueueLength = 1000;

        /// <summary>
        /// Header prepended to each packet.
        /// </summary>
        private byte[] header;

        /// <summary>
        /// Index at which the packet number starts in a packet.
        /// </summary>
        private int packetNumberPosition;

        /// <summary>
        /// Index at which the packet length starts in a packet.
        /// </summary>
        private int packetLengthPosition;

        /// <summary>
        /// Index at which the command type starts in a packet.
        /// </summary>
        private int commandTypePosition;

        /// <summary>
        /// Index at which the packet body starts in a packet.
        /// </summary>
        private int payloadPosition;

        /// <summary>
        /// Maximum size total of a packet.
        /// </summary>
        private ushort maxPacketSize;

        /// <summary>
        /// Maximum body size of a single packet.
        /// </summary>
        private ushort maxBodySize;

        /// <summary>
        /// List of known serializers and deserializers mapped by command type.
        /// </summary>
        private Dictionary<uint, Tuple<CommandDeserializer, CommandSerializer>> serializers =
            new Dictionary<uint, Tuple<CommandDeserializer, CommandSerializer>>();

        /// <summary>
        /// Method used for deserializing game info.
        /// </summary>
        GameInfoDeserializer<TGameInfo> gameInfoDeserializer;

        /// <summary>
        /// Method used for serializing game info.
        /// </summary>
        GameInfoSerializer gameInfoSerializer;

        /// <summary>
        /// The port our protocol should run on.
        /// </summary>
        private ushort port;

        /// <summary>
        /// The endpoint representing a broadcast.
        /// </summary>
        private IPEndPoint broadcastEndpoint;
        
        /// <summary>
        /// Used to distribute unique ids to packets by continuously incrementing this value.
        /// </summary>
        private long packetNumberCounter;

        /// <summary>
        /// Current state of the connection.
        /// </summary>
        private State state = State.Unconnected;

        /// <summary>
        /// The socket used for this UDP connection (sending and receiving).
        /// </summary>
        private Socket socket;

        /// <summary>
        /// Buffer used to receive packets.
        /// </summary>
        private byte[] receiveBuffer;

        /// <summary>
        /// Utility class to allow reuse of send buffers.
        /// </summary>
        private PacketPool packetPool;

        /// <summary>
        /// List of commands received since the last retrieval via Receive().
        /// </summary>
        private Stack<ICommand> receivedCommands = new Stack<ICommand>();

        /// <summary>
        /// Remember IDs of recent commands we ever received, to pass on each one only once.
        /// 
        /// Maps IP-Address -> command IDs.
        /// </summary>
        private Dictionary<int, Queue<long>> receivedCommandIDsBySender =
            new Dictionary<int, Queue<long>>();

        /// <summary>
        /// Commands we sent and are still waiting for acks. These will be resent
        /// according to their priority. There will likely never be so many pending
        /// sends that we get performance problems just iterating over it, so that's
        /// what we do.
        /// </summary>
        private List<Packet> awaitingAck = new List<Packet>();

        /// <summary>
        /// List of commands we got an ack for (won't send and re-push when next encountered).
        /// </summary>
        private HashSet<long> haveAck = new HashSet<long>();

        /// <summary>
        /// List of known other clients.
        /// </summary>
        private List<IPEndPoint> knownClients = new List<IPEndPoint>();

        /// <summary>
        /// Generate a new protocol (handler) for a protocol with the given header information.
        /// </summary>
        /// <param name="name">the name of the protocol.</param>
        /// <param name="version">the version of the protocol. Change this when changing the
        /// command serializers added to the protocol.</param>
        /// <param name="maxPacketSize">the maximum allowed size of packets to send, including
        /// the header itself, in bytes.</param>
        public UDPProtocol(string name, byte version, ushort maxPacketSize = 512)
        {
            int nameByteLength = Encoding.UTF8.GetByteCount(name);
            //                                        version        maxLength
            packetNumberPosition = nameByteLength + sizeof(byte) + sizeof(ushort);
            //                                               number
            packetLengthPosition = packetNumberPosition + sizeof(long);
            //                                              length
            commandTypePosition = packetLengthPosition + sizeof(ushort);
            //                                          type
            payloadPosition = commandTypePosition + sizeof(uint);
            if (payloadPosition >= maxPacketSize)
            {
                throw new ArgumentException("Header size too large, no space left for body.");
            }
            this.maxPacketSize = maxPacketSize;
            maxBodySize = (ushort)(maxPacketSize - payloadPosition);

            header = new byte[payloadPosition];
            receiveBuffer = new byte[maxPacketSize];

            // Push stuff to send buffer that will not change: name, version, max length.
            // This will basically serve as a protocol ID.
            Encoding.UTF8.GetBytes(name).CopyTo(header, 0);
            header[nameByteLength] = version;
            BitConverter.GetBytes(maxPacketSize).CopyTo(header, nameByteLength + sizeof(byte));

            packetPool = new PacketPool(maxPacketSize, header, 256);

            // Register internal command serializers.
            serializers[0] = Tuple.Create<CommandDeserializer, CommandSerializer>
                (AckCommand.Deserialize, AckCommand.Serialize);
            serializers[1] = Tuple.Create<CommandDeserializer, CommandSerializer>
                (GameQueryCommand.Deserialize, GameQueryCommand.Serialize);
            serializers[2] = Tuple.Create<CommandDeserializer, CommandSerializer>
                (GameInfoCommand.Deserialize, GameInfoCommand.Serialize);

            // Set the frame number to some random value. This way we can
            // be pretty sure we're not getting into the trouble of someone
            // ignoring us because of an earlier connection from this machine.
            packetNumberCounter = new Random().Next(0, int.MaxValue);
        }

        /// <summary>
        /// Send a packet to the given remote address.
        /// </summary>
        /// <param name="command">the command to send.</param>
        /// <param name="remote">the address to send it to.</param>
        /// <param name="priority">the priority (resend delay).</param>
        private void Send(ICommand command, IPEndPoint remote, int priority)
        {
            if (!serializers.ContainsKey(command.Type))
            {
                throw new ArgumentException("Unknown command, cannot serialize.", "command");
            }
            
            // Build a packet.
            Packet packet = packetPool.GetPacket();

            // Add remote address, for resending.
            if (remote == null)
            {
                packet.remote = broadcastEndpoint;
            }
            else
            {
                packet.remote = remote;
            }

            // Remember how long to wait before resending.
            packet.resendDelay = priority;

            // Send first try as soon as possible! (in the past :D)
            packet.sendNext = DateTime.Now.Ticks - 100;
            
            // Get a new unique id for this packet.
            lock (this)
            {
                packet.number = packetNumberCounter++;
            }

            // Write the data to it.
            ushort bodyLength = serializers[command.Type].Item2(command, packet.buffer, payloadPosition);
            BitConverter.GetBytes(packet.number).CopyTo(packet.buffer, packetNumberPosition);
            BitConverter.GetBytes(bodyLength).CopyTo(packet.buffer, packetLengthPosition);
            BitConverter.GetBytes(command.Type).CopyTo(packet.buffer, commandTypePosition);
            
            // Remember the actual length of the packet.
            packet.length = (ushort)(payloadPosition + bodyLength);

            // Push it to the queue for sending / resending.
            awaitingAck.Add(packet);

            // Trigger send.
            ResendPackets();
        }

        private void ResendPackets()
        {
            long now = DateTime.Now.Ticks;
            // Lock it for the possible deletes (reads alone wouldn't be a problem,
            // because we're the only consumer).
            lock (awaitingAck)
            {
                for (var i = awaitingAck.Count - 1; i >= 0; --i)
                {
                    Packet packet = awaitingAck[i];

                    // Already got an ack for this one?
                    if (haveAck.Contains(packet.number))
                    {
                        awaitingAck.RemoveAt(i);
                    }
                    else
                    {
                        // Is it time to send it again?
                        if (packet.sendNext < now)
                        {
                            Console.WriteLine("Sending packet of length " + packet.length);
                            socket.BeginSendTo(packet.buffer, 0, packet.length, SocketFlags.None, packet.remote, new AsyncCallback(MessageSentCallback), this);
                            if (packet.resendDelay > 0)
                            {
                                packet.sendNext = now + packet.resendDelay; // or += delay in case this is called too slowly?
                            }
                            else
                            {
                                // Oneshot.
                                packetPool.ReleasePacket(packet);
                                awaitingAck.RemoveAt(i);
                            }
                        }
                    }
                }
            }
        }

        private void HandleCommand(ICommand command, IPEndPoint remote, int remoteAddress)
        {
            switch (command.Type)
            {
                // Lowest 10 are unacked!

                // Ack
                case 0:
                    haveAck.Add(((AckCommand)command).PacketNumber);
                    break;

                // Game query
                case 1:
                    if (state == State.Host)
                    {
                        Send(new GameInfoCommand(gameInfoSerializer()), remote, 0);
                    }
                    break;

                // Game info
                case 2:
                    if (state == State.Unconnected)
                    {
                        OnGameFound(gameInfoDeserializer(remote, ((GameInfoCommand)command).Data));
                    }
                    break;

                // reserved
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                    Console.WriteLine("Received unknown system command: {0}.", command.Type);
                    break;

                // Here begin the acked packages.

                // Client join
                case 10:
                    break;
                // Client leave
                case 11:
                    break;

                // reserved
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                    Console.WriteLine("Received unknown system command: {0}.", command.Type);
                    break;

                // Custom, non-engine internal commands.
                default:
                    // Push command to the list of received ones if we got here.
                    lock (receivedCommands)
                    {
                        receivedCommands.Push(command);
                    }
                    break;
            }
        }

#region Send / Receive loops

        private void BeginReceiveMessage()
        {
            var receiveEndpoint = (EndPoint)new IPEndPoint(IPAddress.Any, port);
            socket.BeginReceiveFrom(receiveBuffer, 0, receiveBuffer.Length, SocketFlags.None,
                ref receiveEndpoint, new AsyncCallback(MessageReceivedCallback), this);

            // Trigger send.
            ResendPackets();
        }

        private void MessageReceivedCallback(IAsyncResult result)
        {
            try
            {
                // Try to finish receiving!
                EndPoint remoteEndPoint = new IPEndPoint(0, 0);
                int bytesRead = socket.EndReceiveFrom(result, ref remoteEndPoint);

                if (remoteEndPoint.Equals(socket.LocalEndPoint))
                {
                    // Ignore packets we sent ourselves.
                }
                if (bytesRead < payloadPosition || !IsValidHeader())
                {
                    // Packet not part of our protocol. Silently drop these.
                }
                else if (bytesRead > maxPacketSize)
                {
                    // Invalid packet, too large.
                    Console.WriteLine("Invalid UDP packet received: packet size exceeds limit.");
                }
                else
                {
                    Console.WriteLine("Received packet of length " + bytesRead);

                    // Get the packet number.
                    long packetNumber = BitConverter.ToInt64(receiveBuffer, packetNumberPosition);

                    // Get the length of the payload.
                    ushort packetLength = BitConverter.ToUInt16(receiveBuffer, packetLengthPosition);

                    if (packetLength > maxBodySize)
                    {
                        // Packet was too large to fit in our receive buffer,
                        // meaning this packet does not belong to our protocol,
                        // and the header fit by pure chance... or malevolence :P
                        Console.WriteLine("Invalid UDP packet received: body size exceeds limit.");
                    }
                    else
                    {
                        // Parse body.
                        uint commandType = BitConverter.ToUInt32(receiveBuffer, commandTypePosition);

                        // Do we know this command type?
                        if (!serializers.ContainsKey(commandType))
                        {
                            // Invalid packet, we cannot handle this command.
                            Console.WriteLine("Invalid UDP packet received: unknown command type.");
                        }
                        else
                        {
                            ICommand command = serializers[commandType].Item1(receiveBuffer, payloadPosition, bytesRead);

                            // Send or resend ack (but don't ack lowest level system commands, which are informational).
                            if (command.Type > 10)
                            {
                                Send(new AckCommand(packetNumber), (IPEndPoint)remoteEndPoint, 0);
                            }

                            // Get the remote address in long form for duplicate checks.
                            int remoteAddress = BitConverter.ToInt32(((IPEndPoint)remoteEndPoint).Address.GetAddressBytes(), 0);

                            // Test if we already received this command before, if so ignore it.
                            if (!receivedCommandIDsBySender.ContainsKey(remoteAddress))
                            {
                                receivedCommandIDsBySender.Add(remoteAddress, new Queue<long>());
                            }
                            if (!receivedCommandIDsBySender[remoteAddress].Contains(packetNumber))
                            {
                                // First time, store it and handle it.
                                receivedCommandIDsBySender[remoteAddress].Enqueue(packetNumber);
                                if (receivedCommandIDsBySender[remoteAddress].Count >= MaxQueueLength)
                                {
                                    receivedCommandIDsBySender[remoteAddress].Dequeue();
                                }
                                HandleCommand(command, (IPEndPoint)remoteEndPoint, remoteAddress);
                            }
                            else
                            {
                                Console.WriteLine("Discarding command of type " + command.Type);
                            }
                        }
                    }
                }
            }
            catch (SocketException e)
            {
                // TODO Kablam! Need an OnDisconnect event handler for this.
                Console.WriteLine("Error: {0} {1}", e.ErrorCode, e.Message);
            }

            // Start waiting for the next message.
            BeginReceiveMessage();
        }

        private void MessageSentCallback(IAsyncResult result)
        {
            try
            {
                socket.EndSendTo(result);
            }
            catch (SocketException e)
            {
                Console.WriteLine("Error: {0} {1}", e.ErrorCode, e.Message);
            }

            // Trigger next sends.
            ResendPackets();
        }

#endregion

#region Utility stuff

        /// <summary>
        /// Test protocol id and version.
        /// </summary>
        /// <returns>true if the header is valid.</returns>
        private bool IsValidHeader()
        {
            for (var i = 0; i < packetNumberPosition; ++i)
            {
                if (receiveBuffer[i] != header[i])
                {
                    // Packet not part of our protocol.
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Struct used for keeping track of a single packet that should
        /// (re)sent. This is stored for prioritized packets until an
        /// ack is received and resent in intervals determined by the priority.
        /// </summary>
        private sealed class Packet
        {
            /// <summary>
            /// Remote point to send to.
            /// </summary>
            public IPEndPoint remote;

            /// <summary>
            /// Packet number.
            /// </summary>
            public long number;

            /// <summary>
            /// Delay between resend tries.
            /// </summary>
            public long resendDelay;

            /// <summary>
            /// Next time to try sending it.
            /// </summary>
            public long sendNext;

            /// <summary>
            /// The data to send.
            /// </summary>
            public byte[] buffer;

            /// <summary>
            /// Length of the relevant data in the buffer.
            /// </summary>
            public ushort length;
        }

        /// <summary>
        /// Used for reusable packets (avoid memory fragmentation).
        /// </summary>
        private sealed class PacketPool
        {
            private Stack<Packet> packets;

            public PacketPool(ushort bufferSize, byte[] header, int maxNumPackets)
            {
                packets = new Stack<Packet>(maxNumPackets);
                for (int i = 0; i < maxNumPackets; i++)
                {
                    Packet packet = new Packet();
                    packet.buffer = new byte[bufferSize];
                    header.CopyTo(packet.buffer, 0);
                    packets.Push(packet);
                }
            }

            public Packet GetPacket()
            {
                lock (packets)
                {
                    return packets.Pop();
                }
            }

            public void ReleasePacket(Packet packet)
            {
                lock (packets)
                {
                    packets.Push(packet);
                }
            }
        }

#endregion

    }
}
