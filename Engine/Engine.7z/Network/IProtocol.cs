﻿using System.Net;
using Engine.Commands;

namespace Engine.Network
{
    /// <summary>
    /// Priority with which messages can be sent.
    /// </summary>
    public enum Priority
    {
        /// <summary>
        /// Only sent once, may never reach its addressee.
        /// </summary>
        Informational,

        /// <summary>
        /// Sent every once in a while, things that are not essential to the gameplay.
        /// For example: purely display related things (different player model, changed
        /// unit selection, chat messages, ...)
        /// </summary>
        Low,

        /// <summary>
        /// Sent relatively often, gameplay relevant but allows for a slight delay.
        /// For example: continuous events such as accelerating a vehicle.
        /// </summary>
        Normal,

        /// <summary>
        /// Spammed like there is no tomorrow, for commands that allow only minimal delay.
        /// For example: firing a weapon that hits instantly.
        /// </summary>
        High
    }

    /// <summary>
    /// Defines the interface to a function capable of deserializing a
    /// command from a byte array, starting at the given position.
    /// </summary>
    /// <param name="buffer">the byte array to deserialize from.</param>
    /// <param name="startIndex">the index to start reading from.</param>
    /// <param name="maxIndex">the maximum length to read, after which data will be invalid.</param>
    /// <returns>A new ICommand instance based on the given buffer.</returns>
    public delegate ICommand CommandDeserializer(byte[] buffer, int startIndex, int maxIndex);

    /// <summary>
    /// Defines the interface to a function capable of serializing a
    /// command to a byte array, starting at the given position.
    /// </summary>
    /// <param name="command">the command to serialize.</param>
    /// <param name="buffer">the buffer to write to.</param>
    /// <param name="startIndex">the index to start writing at.</param>
    /// <returns>the number of bytes written.</returns>
    public delegate ushort CommandSerializer(ICommand command, byte[] buffer, int startIndex);

    /// <summary>
    /// Interface for methods used to deserialize received game information.
    /// </summary>
    /// <typeparam name="TGameInfo">the type of the game information object.</typeparam>
    /// <param name="buffer">the buffer to read from.</param>
    /// <returns>the object parsed from the buffer.</returns>
    public delegate TGameInfo GameInfoDeserializer<TGameInfo>(IPEndPoint host, byte[] buffer);

    /// <summary>
    /// Interface for methods used to serialize a game information object.
    /// </summary>
    /// <returns>a serialized game info object.</returns>
    public delegate byte[] GameInfoSerializer();

    /// <summary>
    /// Signature for game found event handlers.
    /// </summary>
    /// <typeparam name="TGameInfo">the type of the game information object.</typeparam>
    /// <param name="game">the game information.</param>
    public delegate void GameFoundDelegate<TGameInfo>(TGameInfo game);

    /// <summary>
    /// Signature for client join event handlers.
    /// </summary>
    /// <param name="id">the id of the client that joined.</param>
    public delegate void ClientJoinedDelegate(int id);

    /// <summary>
    /// Signature for client leave event handlers.
    /// </summary>
    /// <param name="id">the id of the player that left.</param>
    public delegate void ClientLeftDelegate(int id);

    public interface IProtocol<TGameInfo>
    {

        /// <summary>
        /// Event dispatched whenever a game is found, either due to our own
        /// query or just because it was sent via broadcast.
        /// </summary>
        event GameFoundDelegate<TGameInfo> OnGameFound;

        /// <summary>
        /// Event dispatched when a new client joins a group.
        /// </summary>
        event ClientJoinedDelegate OnPlayerJoined;

        /// <summary>
        /// Event dispatched when a client leaves the group.
        /// </summary>
        event ClientLeftDelegate OnPlayerLeft;

        /// <summary>
        /// The id of the local client for the game he is currently in.
        /// </summary>
        int ClientId { get; }

        /// <summary>
        /// Register a new command deserializer with this protocol, which is used to
        /// parse incoming packets. Note that the range from 0 to 20 is reserved for
        /// internal use.
        /// </summary>
        /// <param name="commandType">the type of the command the deserializer can handle.</param>
        /// <param name="deserializer">the actual deserializer implementation.</param>
        void SetSerializer(uint commandType, CommandDeserializer deserializer, CommandSerializer serializer);

        /// <summary>
        /// Set the serializers used for game info data.
        /// </summary>
        /// <param name="deserializer">the function used to deserialize the game info.</param>
        /// <param name="serializer">the function used to serialize the game info.</param>
        void SetSerializer(GameInfoDeserializer<TGameInfo> deserializer, GameInfoSerializer serializer);
        
        /// <summary>
        /// Initialize network connectivity by opening a socket on the given port.
        /// This must be the same port on all clients. All serializers must be set
        /// before calling this, no network commands (FindHosts, Host, Join, Send,
        /// Receive) will function before calling this.
        /// </summary>
        /// <param name="port">the port the protocol runs on.</param>
        void Init(ushort port);

        /// <summary>
        /// Send a query into the void to look if any games are running in the local network.
        /// </summary>
        void FindHosts();
        
        /// <summary>
        /// Start hosting a game.
        /// 
        /// This only determines how we respond to queries for open games
        /// from other clients (vie FindHosts) and join requests. If such
        /// commands arrive which in client mode (unconnected / joined)
        /// no events are raised.
        /// </summary>
        void Host();
        
        /// <summary>
        /// Join a game based on the address of the hosting machine.
        /// </summary>
        /// <param name="host">the address of the game host.</param>
        void Join(IPEndPoint host);

        /// <summary>
        /// Leave the current game
        /// </summary>
        void Leave();

        /// <summary>
        /// Check if there are any new messages, and if so retrieve them.
        /// This will clear the internal list of received messages.
        /// </summary>
        /// <returns>the list of new messages.</returns>
        ICommand[] Receive();
        
        /// <summary>
        /// Send a packet to the given player. This method will only have
        /// an effect if in a game (hosted or joined).
        /// 
        /// To send a message to all players, use 0 as the player number.
        /// </summary>
        /// <param name="command">the command to send.</param>
        /// <param name="player">the player to send it to.</param>
        /// <param name="priority">the priority of the command.</param>
        void Send(ICommand command, int player = 0, Priority priority = Priority.Informational);
    }
}
