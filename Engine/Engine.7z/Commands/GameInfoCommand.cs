﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Engine.Commands
{
    class GameInfoCommand : Command
    {

        public static ICommand Deserialize(byte[] buffer, int startIndex, int maxIndex)
        {
            var result = new GameInfoCommand();
            result.Data = new byte[maxIndex - startIndex];
            Array.Copy(buffer, startIndex, result.Data, 0, maxIndex - startIndex);
            return result;
        }

        public static ushort Serialize(ICommand command, byte[] buffer, int startIndex)
        {
            var gameInfo = (GameInfoCommand)command;

            gameInfo.Data.CopyTo(buffer, startIndex);

            return (ushort)gameInfo.Data.Length;
        }

        /// <summary>
        /// The game info in serialized form.
        /// </summary>
        public byte[] Data { get; private set; }

        public GameInfoCommand(byte[] gameInfo)
            : base(2)
        {
            this.Data = gameInfo;
        }

        /// <summary>
        /// For deserialization.
        /// </summary>
        public GameInfoCommand()
            : base(2)
        {
        }

    }
}
