﻿using System;

namespace Engine.Commands
{
    /// <summary>
    /// This command signals the sender successfully received a package.
    /// </summary>
    sealed class AckCommand : Command
    {

        public static ICommand Deserialize(byte[] buffer, int startIndex, int maxIndex)
        {
            var result = new AckCommand();
            if (maxIndex - startIndex < sizeof(long))
            {
                throw new ArgumentException();
            }
            result.PacketNumber = BitConverter.ToInt64(buffer, startIndex);
            return result;
        }

        public static ushort Serialize(ICommand command, byte[] buffer, int startIndex)
        {
            var ack = (AckCommand)command;
            BitConverter.GetBytes(ack.PacketNumber).CopyTo(buffer, startIndex);

            return sizeof(long);
        }

        /// <summary>
        /// The packet number acknowledged via this ack.
        /// </summary>
        public long PacketNumber { get; private set; }

        /// <summary>
        /// Creates a new ack command, acknowledging the given packet.
        /// </summary>
        /// <param name="packetNumber">the number of the acknowledged packet.</param>
        public AckCommand(long packetNumber)
            : base(0)
        {
            this.PacketNumber = packetNumber;
        }

        /// <summary>
        /// For deserialization.
        /// </summary>
        private AckCommand()
            : base(0)
        {
        }
    }
}
