﻿using System;

namespace Engine.Commands
{
    /// <summary>
    /// Base class for commands.
    /// </summary>
    public abstract class Command : ICommand
    {

        protected Command(uint type)
        {
            Type = type;
        }

        public uint Type { get; private set; }

        // set via protocol
        public bool IsTentative { get; set; }

        // set via protocol
        public int Player { get; set; }

    }
}
