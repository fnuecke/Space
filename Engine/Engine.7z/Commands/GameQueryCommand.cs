﻿namespace Engine.Commands
{
    /// <summary>
    /// Signals the sender tries to find open games.
    /// </summary>
    sealed class GameQueryCommand : Command
    {

        public static ICommand Deserialize(byte[] buffer, int startIndex, int maxIndex)
        {
            return new GameQueryCommand();
        }

        public static ushort Serialize(ICommand command, byte[] buffer, int startIndex)
        {
            return 0;
        }

        /// <summary>
        /// Creates a new command representing a query for open games.
        /// </summary>
        public GameQueryCommand()
            : base(1)
        {
        }

    }
}
