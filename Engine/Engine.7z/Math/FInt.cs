﻿using System.Runtime.Serialization;
using System;

namespace Engine.Math
{
    /// <summary>
    /// Represents a fixed-point number.
    /// </summary>
    /// <see cref="http://stackoverflow.com/questions/605124/fixed-point-math-in-c"/>
    public struct FInt
    {

        #region Private constants
        private const int SHIFT_AMOUNT = 12; //12 is 4096
        private const long One = 1 << SHIFT_AMOUNT;
        private const int OneI = 1 << SHIFT_AMOUNT;
        private static FInt OneF = FInt.Create(1, true);
        private static FInt PI = FInt.Create(12868, false); // PI x 2^12
        private static FInt TwoPIF = PI * 2; // radian equivalent of 360 degrees
        private static FInt PIOver180F = PI / (FInt)180; // PI / 180
        #endregion

        // Actual value holder of this instance.
        private long RawValue;

        #region Constructors
        public static FInt Create(long StartingRawValue, bool UseMultiple)
        {
            FInt fInt;
            fInt.RawValue = StartingRawValue;
            if (UseMultiple)
                fInt.RawValue = fInt.RawValue << SHIFT_AMOUNT;
            return fInt;
        }
        public static FInt Create(double DoubleValue)
        {
            FInt fInt;
            DoubleValue *= (double)One;
            fInt.RawValue = (int)System.Math.Round(DoubleValue);
            return fInt;
        }
        #endregion

        #region Conversions
        public int IntValue
        {
            get { return (int)(this.RawValue >> SHIFT_AMOUNT); }
        }

        public double DoubleValue
        {
            get { return (double)this.RawValue / (double)One; }
        }
        #endregion

        #region FromParts
        /// <summary>
        /// Create a fixed-int number from parts.  For example, to create 1.5 pass in 1 and 500.
        /// </summary>
        /// <param name="PreDecimal">The number above the decimal.  For 1.5, this would be 1.</param>
        /// <param name="PostDecimal">The number below the decimal, to three digits.  
        /// For 1.5, this would be 500. For 1.005, this would be 5.</param>
        /// <returns>A fixed-int representation of the number parts</returns>
        public static FInt FromParts(int PreDecimal, int PostDecimal)
        {
            FInt f = FInt.Create(PreDecimal, true);
            if (PostDecimal != 0)
                f.RawValue += (FInt.Create(PostDecimal) / 1000).RawValue;

            return f;
        }
        #endregion

        #region *
        public static FInt operator *(FInt one, FInt other)
        {
            FInt fInt;
            fInt.RawValue = (one.RawValue * other.RawValue) >> SHIFT_AMOUNT;
            return fInt;
        }

        public static FInt operator *(FInt one, int multi)
        {
            return one * (FInt)multi;
        }

        public static FInt operator *(int multi, FInt one)
        {
            return one * (FInt)multi;
        }
        #endregion

        #region /
        public static FInt operator /(FInt one, FInt other)
        {
            FInt fInt;
            fInt.RawValue = (one.RawValue << SHIFT_AMOUNT) / (other.RawValue);
            return fInt;
        }

        public static FInt operator /(FInt one, int divisor)
        {
            return one / (FInt)divisor;
        }

        public static FInt operator /(int divisor, FInt one)
        {
            return (FInt)divisor / one;
        }
        #endregion

        #region %
        public static FInt operator %(FInt one, FInt other)
        {
            FInt fInt;
            fInt.RawValue = (one.RawValue) % (other.RawValue);
            return fInt;
        }

        public static FInt operator %(FInt one, int divisor)
        {
            return one % (FInt)divisor;
        }

        public static FInt operator %(int divisor, FInt one)
        {
            return (FInt)divisor % one;
        }
        #endregion

        #region +
        public static FInt operator +(FInt one, FInt other)
        {
            FInt fInt;
            fInt.RawValue = one.RawValue + other.RawValue;
            return fInt;
        }

        public static FInt operator +(FInt one, int other)
        {
            return one + (FInt)other;
        }

        public static FInt operator +(int other, FInt one)
        {
            return one + (FInt)other;
        }
        #endregion

        #region -
        public FInt Inverse
        {
            get { return FInt.Create(-this.RawValue, false); }
        }

        public static FInt operator -(FInt one)
        {
            return one.Inverse;
        }

        public static FInt operator -(FInt one, FInt other)
        {
            FInt fInt;
            fInt.RawValue = one.RawValue - other.RawValue;
            return fInt;
        }

        public static FInt operator -(FInt one, int other)
        {
            return one - (FInt)other;
        }

        public static FInt operator -(int other, FInt one)
        {
            return (FInt)other - one;
        }
        #endregion

        #region ==
        public static bool operator ==(FInt one, FInt other)
        {
            return one.RawValue == other.RawValue;
        }

        public static bool operator ==(FInt one, int other)
        {
            return one == (FInt)other;
        }

        public static bool operator ==(int other, FInt one)
        {
            return (FInt)other == one;
        }
        #endregion

        #region !=
        public static bool operator !=(FInt one, FInt other)
        {
            return one.RawValue != other.RawValue;
        }

        public static bool operator !=(FInt one, int other)
        {
            return one != (FInt)other;
        }

        public static bool operator !=(int other, FInt one)
        {
            return (FInt)other != one;
        }
        #endregion

        #region >=
        public static bool operator >=(FInt one, FInt other)
        {
            return one.RawValue >= other.RawValue;
        }

        public static bool operator >=(FInt one, int other)
        {
            return one >= (FInt)other;
        }

        public static bool operator >=(int other, FInt one)
        {
            return (FInt)other >= one;
        }
        #endregion

        #region <=
        public static bool operator <=(FInt one, FInt other)
        {
            return one.RawValue <= other.RawValue;
        }

        public static bool operator <=(FInt one, int other)
        {
            return one <= (FInt)other;
        }

        public static bool operator <=(int other, FInt one)
        {
            return (FInt)other <= one;
        }
        #endregion

        #region >
        public static bool operator >(FInt one, FInt other)
        {
            return one.RawValue > other.RawValue;
        }

        public static bool operator >(FInt one, int other)
        {
            return one > (FInt)other;
        }

        public static bool operator >(int other, FInt one)
        {
            return (FInt)other > one;
        }
        #endregion

        #region <
        public static bool operator <(FInt one, FInt other)
        {
            return one.RawValue < other.RawValue;
        }

        public static bool operator <(FInt one, int other)
        {
            return one < (FInt)other;
        }

        public static bool operator <(int other, FInt one)
        {
            return (FInt)other < one;
        }
        #endregion

        #region Casting
        public static explicit operator int(FInt src)
        {
            return (int)(src.RawValue >> SHIFT_AMOUNT);
        }

        public static explicit operator FInt(int src)
        {
            return FInt.Create(src, true);
        }

        public static explicit operator FInt(long src)
        {
            return FInt.Create(src, true);
        }

        public static explicit operator FInt(ulong src)
        {
            return FInt.Create((long)src, true);
        }
        #endregion

        #region Bitshifts
        public static FInt operator <<(FInt one, int Amount)
        {
            return FInt.Create(one.RawValue << Amount, false);
        }

        public static FInt operator >>(FInt one, int Amount)
        {
            return FInt.Create(one.RawValue >> Amount, false);
        }
        #endregion

        #region Sqrt
        public static FInt Sqrt(FInt f, int NumberOfIterations)
        {
            if (f.RawValue < 0) //NaN in Math.Sqrt
                throw new ArithmeticException("Input Error");
            if (f.RawValue == 0)
                return (FInt)0;
            FInt k = f + FInt.OneF >> 1;
            for (int i = 0; i < NumberOfIterations; i++)
                k = (k + (f / k)) >> 1;

            if (k.RawValue < 0)
                throw new ArithmeticException("Overflow");
            else
                return k;
        }

        public static FInt Sqrt(FInt f)
        {
            byte numberOfIterations = 8;
            if (f.RawValue > 0x64000)
                numberOfIterations = 12;
            if (f.RawValue > 0x3e8000)
                numberOfIterations = 16;
            return Sqrt(f, numberOfIterations);
        }
        #endregion

        #region Sin
        public static FInt Sin(FInt i)
        {
            FInt j = (FInt)0;
            for (; i < 0; i += FInt.Create(25736, false)) ;
            if (i > FInt.Create(25736, false))
                i %= FInt.Create(25736, false);
            FInt k = (i * FInt.Create(10, false)) / FInt.Create(714, false);
            if (i != 0 && i != FInt.Create(6434, false) && i != FInt.Create(12868, false) &&
                i != FInt.Create(19302, false) && i != FInt.Create(25736, false))
                j = (i * FInt.Create(100, false)) / FInt.Create(714, false) - k * FInt.Create(10, false);
            if (k <= FInt.Create(90, false))
                return sin_lookup(k, j);
            if (k <= FInt.Create(180, false))
                return sin_lookup(FInt.Create(180, false) - k, j);
            if (k <= FInt.Create(270, false))
                return sin_lookup(k - FInt.Create(180, false), j).Inverse;
            else
                return sin_lookup(FInt.Create(360, false) - k, j).Inverse;
        }

        private static FInt sin_lookup(FInt i, FInt j)
        {
            if (j > 0 && j < FInt.Create(10, false) && i < FInt.Create(90, false))
                return FInt.Create(SIN_TABLE[i.RawValue], false) +
                    ((FInt.Create(SIN_TABLE[i.RawValue + 1], false) - FInt.Create(SIN_TABLE[i.RawValue], false)) /
                    FInt.Create(10, false)) * j;
            else
                return FInt.Create(SIN_TABLE[i.RawValue], false);
        }

        private static int[] SIN_TABLE = {
        0, 71, 142, 214, 285, 357, 428, 499, 570, 641, 
        711, 781, 851, 921, 990, 1060, 1128, 1197, 1265, 1333, 
        1400, 1468, 1534, 1600, 1665, 1730, 1795, 1859, 1922, 1985, 
        2048, 2109, 2170, 2230, 2290, 2349, 2407, 2464, 2521, 2577, 
        2632, 2686, 2740, 2793, 2845, 2896, 2946, 2995, 3043, 3091, 
        3137, 3183, 3227, 3271, 3313, 3355, 3395, 3434, 3473, 3510, 
        3547, 3582, 3616, 3649, 3681, 3712, 3741, 3770, 3797, 3823, 
        3849, 3872, 3895, 3917, 3937, 3956, 3974, 3991, 4006, 4020, 
        4033, 4045, 4056, 4065, 4073, 4080, 4086, 4090, 4093, 4095, 
        4096
    };
        #endregion

        #region Cos, Tan, Asin
        public static FInt Cos(FInt i)
        {
            return Sin(i + FInt.Create(6435, false));
        }

        public static FInt Tan(FInt i)
        {
            return Sin(i) / Cos(i);
        }

        public static FInt Asin(FInt F)
        {
            bool isNegative = F < 0;
            F = Abs(F);

            if (F > FInt.OneF)
                throw new ArithmeticException("Bad Asin Input:" + F.DoubleValue);

            FInt f1 = mul(mul(mul(mul(FInt.Create(145103 >> FInt.SHIFT_AMOUNT, false), F) -
                FInt.Create(599880 >> FInt.SHIFT_AMOUNT, false), F) +
                FInt.Create(1420468 >> FInt.SHIFT_AMOUNT, false), F) -
                FInt.Create(3592413 >> FInt.SHIFT_AMOUNT, false), F) +
                FInt.Create(26353447 >> FInt.SHIFT_AMOUNT, false);
            FInt f2 = PI / FInt.Create(2, true) - (Sqrt(FInt.OneF - F) * f1);

            return isNegative ? f2.Inverse : f2;
        }
        private static FInt mul(FInt F1, FInt F2)
        {
            return F1 * F2;
        }
        #endregion

        #region ATan, ATan2
        public static FInt Atan(FInt F)
        {
            return Asin(F / Sqrt(FInt.OneF + (F * F)));
        }

        public static FInt Atan2(FInt F1, FInt F2)
        {
            if (F2.RawValue == 0 && F1.RawValue == 0)
                return (FInt)0;

            FInt result = (FInt)0;
            if (F2 > 0)
                result = Atan(F1 / F2);
            else if (F2 < 0)
            {
                if (F1 >= 0)
                    result = (PI - Atan(Abs(F1 / F2)));
                else
                    result = (PI - Atan(Abs(F1 / F2))).Inverse;
            }
            else
                result = (F1 >= 0 ? PI : PI.Inverse) / FInt.Create(2, true);

            return result;
        }
        #endregion

        #region Abs
        public static FInt Abs(FInt F)
        {
            if (F < 0)
                return F.Inverse;
            else
                return F;
        }
        #endregion

        #region MaxMin
        public static FInt Max(FInt F1, FInt F2)
        {
            if (F1 > F2)
                return F1;
            else
                return F2;
        }
        public static FInt Min(FInt F1, FInt F2)
        {
            if (F1 < F2)
                return F1;
            else
                return F2;
        }
        #endregion

        public override bool Equals(object obj)
        {
            if (obj is FInt)
            {
                return ((FInt)obj).RawValue == this.RawValue;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return RawValue.GetHashCode();
        }

        public override string ToString()
        {
            return this.RawValue.ToString();
        }
    }

    public struct FPoint
    {
        public FInt X;
        public FInt Y;

        public static FPoint Create(FInt X, FInt Y)
        {
            FPoint fp;
            fp.X = X;
            fp.Y = Y;
            return fp;
        }

        public FInt DistanceTo(FPoint f)
        {
            return FInt.Sqrt((this - f).Length);
        }

        public FInt Norm { get { return X * X + Y * Y; } }

        public FInt Length { get { return FInt.Sqrt(X * X + Y * Y); } }

        #region Vector Operations

        internal static FInt Dot(FPoint F1, FPoint F2)
        {
            return F1.X * F2.X + F1.Y * F2.Y;
        }

        public static FPoint Rotate(FPoint F1, FInt angle)
        {
            FPoint result;
            FInt cos = FInt.Cos(angle);
            FInt sin = FInt.Sin(angle);
            result.X = F1.X * cos - F1.Y * sin;
            result.Y = F1.X * sin + F1.Y * cos;
            return result;
        }

        #region +
        public static FPoint operator +(FPoint F1, FPoint F2)
        {
            FPoint result;
            result.X = F1.X + F2.X;
            result.Y = F1.Y + F2.Y;
            return result;
        }
        #endregion

        #region -
        public static FPoint operator -(FPoint F1, FPoint F2)
        {
            FPoint result;
            result.X = F1.X - F2.X;
            result.Y = F1.Y - F2.Y;
            return result;
        }
        #endregion

        #region *
        public static FPoint operator *(FPoint F1, FInt Multiplier)
        {
            FPoint result;
            result.X = F1.X * Multiplier;
            result.Y = F1.Y * Multiplier;
            return result;
        }
        public static FPoint operator *(FPoint F1, int Multiplier)
        {
            return F1 * (FInt)Multiplier;
        }
        public static FPoint operator *(int Multiplier, FPoint F1)
        {
            return F1 * (FInt)Multiplier;
        }
        #endregion

        #region /
        public static FPoint operator /(FPoint F1, FInt Divisor)
        {
            FPoint result;
            result.X = F1.X / Divisor;
            result.Y = F1.Y / Divisor;
            return result;
        }
        public static FPoint operator /(FPoint F1, int Divisor)
        {
            return F1 / (FInt)Divisor;
        }
        public static FPoint operator /(int Divisor, FPoint F1)
        {
            return F1 / (FInt)Divisor;
        }
        #endregion

        #endregion
    }

    public struct FRectangle
    {
        public FPoint TopLeft;
        public FPoint BottomRight;

        public static FRectangle Create(FPoint topLeft, FPoint bottomRight)
        {
            FRectangle result;
            result.TopLeft = topLeft;
            result.BottomRight = bottomRight;
            return result;
        }
        public static FRectangle Create(FPoint topLeft, FInt width, FInt height)
        {
            FRectangle result;
            result.TopLeft = topLeft;
            result.BottomRight = FPoint.Create(topLeft.X + width, topLeft.Y + height);
            return result;
        }
        public static FRectangle Create(FInt x, FInt y, FInt width, FInt height)
        {
            FRectangle result;
            result.TopLeft = FPoint.Create(x, y);
            result.BottomRight = FPoint.Create(x + width, y + height);
            return result;
        }
        public static FRectangle Create(FPoint size)
        {
            FRectangle result;
            result.TopLeft = FPoint.Create((FInt)0, (FInt)0);
            result.BottomRight = FPoint.Create(size.X, size.Y);
            return result;
        }
        public static FRectangle Create(FInt width, FInt height)
        {
            FRectangle result;
            result.TopLeft = FPoint.Create((FInt)0, (FInt)0);
            result.BottomRight = FPoint.Create(width, height);
            return result;
        }

        public FInt Width { get { return BottomRight.X - TopLeft.X; } }
        public FInt Height { get { return BottomRight.Y - TopLeft.Y; } }
        public FInt Top { get { return TopLeft.Y; } }
        public FInt Right { get { return BottomRight.X; } }
        public FInt Bottom { get { return BottomRight.Y; } }
        public FInt Left { get { return TopLeft.X; } }

        public bool Intersects(FRectangle other)
        {
            return other.Left < Right && other.Right > Left && other.Top < Bottom && other.Bottom > Top;
        }
    }
}