﻿using System;

namespace Engine.Simulation
{
    /// <summary>
    /// Minimal interface to be implemented by simulation states.
    /// </summary>
    public interface IState<TUpdateable> : ICloneable where TUpdateable : ICloneable
    {

        /// <summary>
        /// The current frame of the simulation the state represents.
        /// </summary>
        long CurrentFrame { get; }

        /// <summary>
        /// Add an updateable object to the list of participants of this state.
        /// </summary>
        /// <param name="updateable">the object to add.</param>
        void Add(TUpdateable updateable);

        /// <summary>
        /// Remove an updateable object to the list of participants of this state.
        /// </summary>
        /// <param name="updateable">the object to remove.</param>
        void Remove(TUpdateable updateable);

        /// <summary>
        /// Advance the simulation by one frame.
        /// </summary>
        void Step();

        /// <summary>
        /// Apply a given command to the simulation state.
        /// </summary>
        /// <param name="command">the command to apply.</param>
        void PushCommand(ISimulationCommand command);

    }
}
