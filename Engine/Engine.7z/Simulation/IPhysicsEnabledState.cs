﻿using System;
using System.Collections.Generic;
using Engine.Physics;

namespace Engine.Simulation
{
    public interface IPhysicsEnabledState : IState<IPhysicsSteppable>
    {

        /// <summary>
        /// A list of collideables which registered themselves in the state.
        /// </summary>
        ICollection<ICollideable> Collideables { get; }

    }
}
